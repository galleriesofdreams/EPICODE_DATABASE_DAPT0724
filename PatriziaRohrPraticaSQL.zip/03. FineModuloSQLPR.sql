/* Descrivi la struttura delle tabelle che reputi utili e sufficienti a modellare lo scenario proposto tramite la sintassi DDL. 
Implementa fisicamente le tabelle utilizzando il DBMS SQL Server(o altro).*/

-- Creazione Category
CREATE TABLE Category (
    CategoryId INT AUTO_INCREMENT,
    CategoryName VARCHAR(25),
    CONSTRAINT PK_Category PRIMARY KEY (CategoryID)
);

-- Creazione Product
CREATE TABLE Product (
    ProductID INT AUTO_INCREMENT,
    ProductName VARCHAR(25),
    UnitPrice DECIMAL(5 , 2 ),
    CategoryID INT,
    CONSTRAINT PK_Product PRIMARY KEY (ProductID),
    CONSTRAINT FK_Cat_Prod FOREIGN KEY (CategoryID)
        REFERENCES Category (CategoryID)
);

-- Creazione Region
CREATE TABLE Region (
    RegionID INT AUTO_INCREMENT,
    RegionName VARCHAR(25),
    CONSTRAINT PK_Region PRIMARY KEY (RegionID)
);

-- Creazione Country
CREATE TABLE Country (
    CountryID INT AUTO_INCREMENT,
    CountryName VARCHAR(25),
    RegionID INT,
    CONSTRAINT PK_Country PRIMARY KEY (CountryID),
    CONSTRAINT FK_Country_Region FOREIGN KEY (RegionID)
        REFERENCES Region (RegionID)
);

-- Creazione SalesOrderHeader
CREATE TABLE SalesOrderHeader (
    SalesOrderID INT AUTO_INCREMENT,
    OrderDate DATE,
    SalesAmount DECIMAL(10 , 2 ),
    CONSTRAINT PK_SalesOrderHeader PRIMARY KEY (SalesOrderID)
);

-- Creazione SalesOrderDetail
CREATE TABLE SalesOrderDetail (
    SalesOrderID INT,
    SalesOrderDetailID INT,
    OrderQty SMALLINT,
    LineTotal DECIMAL(5 , 2 ),
    ProductID INT,
    CountryID INT,
    CONSTRAINT PK_SalesOrderDetail PRIMARY KEY (SalesOrderID , SalesOrderDetailID),
    CONSTRAINT FK_Detail_Header FOREIGN KEY (SalesOrderID)
        REFERENCES SalesOrderHeader (SalesOrderID),
    CONSTRAINT FK_Country_Order FOREIGN KEY (CountryID)
        REFERENCES Country (CountryID),
    CONSTRAINT FK_Product_Order FOREIGN KEY (ProductID)
        REFERENCES Product (ProductID)
);

-- Popola le tabelle utilizzando dati a tua discrezione 
-- Tabella Category
INSERT INTO Category (CategoryID, CategoryName) VALUES (1, 'Action Figures');
INSERT INTO Category (CategoryID, CategoryName) VALUES (2, 'Board Games');
INSERT INTO Category (CategoryID, CategoryName) VALUES (3, 'Dolls');
INSERT INTO Category (CategoryID, CategoryName) VALUES (4, 'Outdoor Toys');

-- Tabella Product
INSERT INTO Product (ProductName, UnitPrice, CategoryID) VALUES ('Superhero Action Figure', 15.99, 1);
INSERT INTO Product (ProductName, UnitPrice, CategoryID) VALUES ('Robot Action Figure', 19.99, 1);
INSERT INTO Product (ProductName, UnitPrice, CategoryID) VALUES ('Animal Action Figure', 9.99, 1);
INSERT INTO Product (ProductName, UnitPrice, CategoryID) VALUES ('Monopoly', 29.99, 2);
INSERT INTO Product (ProductName, UnitPrice, CategoryID) VALUES ('Chess Set', 19.99, 2);
INSERT INTO Product (ProductName, UnitPrice, CategoryID) VALUES ('Scrabble', 24.99, 2);
INSERT INTO Product (ProductName, UnitPrice, CategoryID) VALUES ('Barbie Doll', 19.99, 3);
INSERT INTO Product (ProductName, UnitPrice, CategoryID) VALUES ('Cabbage Patch Doll', 22.99, 3);
INSERT INTO Product (ProductName, UnitPrice, CategoryID) VALUES ('Baby Doll', 14.99, 3);
INSERT INTO Product (ProductName, UnitPrice, CategoryID) VALUES ('Frisbee', 7.99, 4);
INSERT INTO Product (ProductName, UnitPrice, CategoryID) VALUES ('Jump Rope', 5.99, 4);
INSERT INTO Product (ProductName, UnitPrice, CategoryID) VALUES ('Soccer Ball', 12.99, 4);
INSERT INTO Product (ProductName, UnitPrice, CategoryID) VALUES ('Old Action Figure', 15.99, 1);

-- Tabella Region
INSERT INTO Region (RegionID, RegionName) VALUES (1, 'Northern Europe');
INSERT INTO Region (RegionID, RegionName) VALUES (2, 'Central Europe');
INSERT INTO Region (RegionID, RegionName) VALUES (3, 'Western Europe');
INSERT INTO Region (RegionID, RegionName) VALUES (4, 'Southern Europe');
INSERT INTO Region (RegionID, RegionName) VALUES (5, 'Eastern Europe');

-- Tabella Country
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (1, 'Sweden', 1);
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (2, 'Denmark', 1);
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (3, 'Finland', 1);
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (4, 'Norway', 1);
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (5, 'Iceland', 1);
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (6, 'Austria', 2);
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (7, 'Switzerland', 2);
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (8, 'Czech Republic', 2);
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (9, 'Slovakia', 2);
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (10, 'Poland', 2);
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (11, 'Germany', 3);
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (12, 'France', 3);
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (13, 'Belgium', 3);
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (14, 'Netherlands', 3);
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (15, 'Luxembourg', 3);
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (16, 'Italy', 4);
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (17, 'Spain', 4);
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (18, 'Greece', 4);
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (19, 'Portugal', 4);
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (20, 'Turkey', 4);
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (21, 'Russia', 5);
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (22, 'Ukraine', 5);
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (23, 'Romania', 5);
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (24, 'Bulgaria', 5);
INSERT INTO Country (CountryID, CountryName, RegionID) VALUES (25, 'Hungary', 5);

-- Tabella SalesOrderHeader
INSERT INTO SalesOrderHeader (SalesOrderID, OrderDate, SalesAmount)
VALUES 
(1, '2023-01-15', 150.00), 
(2, '2023-03-10', 200.00), 
(3, '2023-05-20', 180.00), 
(4, '2023-08-01', 240.00), 
(5, '2023-12-15', 300.00), 
(6, '2024-02-28', 400.00), 
(7, '2024-04-15', 350.00), 
(8, '2024-06-10', 420.00), 
(9, '2024-09-20', 500.00), 
(10, '2024-11-30', 250.00), 
(11, '2025-01-10', 600.00), 
(12, '2025-03-05', 300.00), 
(13, '2025-06-15', 450.00), 
(14, '2025-08-25', 550.00), 
(15, '2025-12-20', 700.00);
 
-- Tabella SalesOrderDetail

INSERT INTO SalesOrderDetail (SalesOrderID, SalesOrderDetailID, OrderQty, LineTotal, ProductID, CountryID)
VALUES
(1, 1, 5, 79.95, 1, 1),
(1, 2, 10, 99.90, 3, 2),
(2, 3, 8, 239.92, 4, 6),
(2, 4, 0, 0.00, 5, 7),
(3, 5, 12, 179.88, 7, 11),
(3, 6, 5, 74.95, 8, 12),
(4, 7, 15, 119.85, 10, 16),
(4, 8, 0, 0.00, 11, 17),
(5, 9, 6, 95.94, 2, 21),
(5, 10, 4, 51.96, 13, 22),
(6, 11, 20, 319.80, 1, 3),
(7, 12, 12, 299.88, 6, 8),
(8, 13, 7, 160.93, 8, 13),
(9, 14, 10, 129.90, 12, 19),
(10, 15, 8, 159.92, 2, 23),
(10, 16, 5, 114.95, 7, 25),
(11, 17, 25, 399.75, 1, 4),
(12, 18, 15, 449.85, 4, 9),
(13, 19, 20, 299.80, 9, 14),
(14, 20, 18, 143.82, 10, 18),
(15, 21, 30, 479.70, 1, 24),
(15, 22, 12, 119.88, 3, 20);

/* Dopo aver popolate le tabelle, scrivi delle query utili a:
1)	Verificare che i campi definiti come PK siano univoci. In altre parole, scrivi una query per determinare l’univocità dei valori di ciascuna PK 
(una query per tabella implementata).*/

-- Verifica Category
SELECT 
    CategoryID, COUNT(*) AS PrimaryKeyCategory
FROM
    Category
GROUP BY CategoryID 
HAVING COUNT(*) > 1
;

-- Verifica Product
SELECT 
    ProductId, COUNT(*) AS PrimaryKeyProduct
FROM
    Product
GROUP BY ProductID 
HAVING COUNT(*) > 1
;

-- Verifica Region
SELECT 
    RegionID, COUNT(*) AS PrimaryKeyRegion
FROM
    Region
GROUP BY RegionID 
HAVING COUNT(*) > 1
;

-- Verifica Country
SELECT 
    CountryID, COUNT(*) AS PrimaryKeyCountry
FROM
    Country
GROUP BY CountryID 
HAVING COUNT(*) > 1
;

-- Verifica SalesOrderHeader
SELECT 
    SalesOrderID, COUNT(*) AS PrimaryKeySalesOrdH
FROM
    SalesOrderHeader
GROUP BY SalesOrderID 
HAVING COUNT(*) > 1
;

-- Verifica SalesOrderDetail
SELECT 
    SalesOrderID, SalesOrderDetailId, COUNT(*) AS PrimaryKeySalesOrdD
FROM
    SalesOrderDetail
GROUP BY SalesOrderID, SalesOrderDetailId
HAVING COUNT(*) > 1
;

/* 2)	Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, la categoria del prodotto, 
il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato in base alla condizione che siano passati più di 180 giorni 
dalla data vendita o meno (>180 -> True, <= 180 -> False) */

SELECT 
    d.SalesOrderId AS CodiceDocumento,
    OrderDate AS DataVendita,
    ProductName AS NomeProdotto,
    CategoryName AS CategoriaProdotto,
    CountryName AS NomeStato,
    RegionName AS NomeRegione,
    CASE
        WHEN DATEDIFF(CURDATE(), h.OrderDate) > 180 THEN TRUE
        ELSE FALSE
    END AS Check_180_giorni
FROM
    SalesOrderHeader h
        JOIN
    SalesOrderDetail d ON h.salesorderID = d.salesorderID
        JOIN
    product p ON d.productID = p.productID
        JOIN
    category c ON p.categoryID = c.categoryID
        JOIN
    country co ON d.countryid = co.countryID
        JOIN
    region r ON co.regionid = r.regionID
;

/* 3) Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite realizzate nell’ultimo anno censito. 
(ogni valore della condizione deve risultare da una query e non deve essere inserito a mano). 
Nel result set devono comparire solo il codice prodotto e il totale venduto.*/

SELECT 
    p.ProductId AS CodiceProdotto, SUM(d.OrderQty) AS TotVenduto
FROM
    Product p
        JOIN
    SalesOrderDetail d ON p.ProductId = d.ProductId
        JOIN
    SalesOrderHeader h ON d.SalesOrderId = h.SalesOrderID
WHERE
    YEAR(OrderDate) = YEAR(CURDATE()) - 1
GROUP BY p.ProductID
HAVING SUM(d.OrderQty) > (SELECT 
        AVG(OrderQty)
    FROM
        SalesOrderDetail d
            JOIN
        SalesOrderHeader h ON d.SalesOrderID = h.SalesOrderID
    WHERE
        YEAR(OrderDate) = YEAR(CURDATE()) - 1);

-- 4) Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. 

SELECT 
    ProductName,
    YEAR(OrderDate) AS Anno,
    SUM(LineTotal) AS FatTOT
FROM
    Product p
        JOIN
    salesorderdetail d ON p.ProductId = d.ProductId
        JOIN
    Salesorderheader h ON d.salesorderID = h.salesorderID
GROUP BY ProductName , Anno
HAVING FatTot > 0
ORDER BY ProductName
;

-- 5) Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.

SELECT 
    CountryName,
    RegionName,
    YEAR(OrderDate) AS OrderYear,
    SUM(h.SalesAmount) AS FatTot
FROM
    SalesOrderDetail s
        JOIN
    Country c ON s.countryID = c.countryID
        JOIN
    SalesOrderHeader h ON s.SalesOrderId = h.SalesOrderId
        JOIN
    Region r ON c.regionid = r.regionID
GROUP BY CountryName , RegionName , OrderDate
ORDER BY OrderYear DESC , FatTot DESC
;

-- 6) Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?

SELECT 
    c.CategoryId, CategoryName, SUM(s.OrderQty) AS OrderQty
FROM
    Category c
        JOIN
    Product p ON c.categoryId = p.categoryID
        JOIN
    salesorderdetail s ON p.productID = s.productID
    GROUP BY CategoryID
    LIMIT 1
;

-- 7) Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti.

-- Approccio 1 con JOIN
SELECT 
    p.ProductId,
    ProductName,
    UnitPrice,
    CategoryName,
    OrderQty,
    LineTotal
FROM
    category c
        JOIN
    product p ON c.categoryid = p.categoryID
        JOIN
    SalesOrderDetail s ON p.productID = s.ProductID
WHERE
    OrderQty = 0
;

-- Approccio 2 con SUBQUERY
SELECT 
    *
FROM
    Product
WHERE
    ProductID IN (SELECT 
            ProductID
        FROM
            SalesOrderDetail
        WHERE
            OrderQty = 0);
            

-- 8) Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle informazioni utili (codice prodotto, nome prodotto, nome categoria)

CREATE VIEW Denorm AS
    (SELECT 
        ProductId, ProductName, CategoryName
    FROM
        Product p
            JOIN
        Category c ON p.categoryId = c.categoryID)
;
	
-- 9) Creare una vista per le informazioni geografiche

CREATE VIEW InfoGeo AS
    (SELECT 
        CountryID, CountryName, r.RegionID, RegionName
    FROM
        region r
            JOIN
        country c ON r.regionID = c.regionID)
;